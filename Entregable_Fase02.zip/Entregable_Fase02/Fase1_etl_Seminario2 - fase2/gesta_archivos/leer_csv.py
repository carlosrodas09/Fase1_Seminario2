import pandas as pd

def obtener_dataframe(path):
    return pd.read_csv(path)





